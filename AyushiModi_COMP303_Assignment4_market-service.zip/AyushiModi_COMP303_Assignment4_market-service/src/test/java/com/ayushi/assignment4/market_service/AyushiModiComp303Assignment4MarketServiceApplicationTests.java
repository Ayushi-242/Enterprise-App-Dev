package com.ayushi.assignment4.market_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushiModiComp303Assignment4MarketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
