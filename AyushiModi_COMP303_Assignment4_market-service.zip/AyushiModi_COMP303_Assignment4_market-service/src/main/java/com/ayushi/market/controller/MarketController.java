package com.ayushi.market.controller;

import com.ayushi.market.model.MarketOrder;
import com.ayushi.market.repository.MarketOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/market")
public class MarketController {

    @Autowired
    private MarketOrderRepository marketOrderRepository;

    @PostMapping("/place-order")
    public String placeOrder(@RequestBody MarketOrder marketOrder) {
        marketOrderRepository.save(marketOrder);
        return "Stock Order for " + marketOrder.getStockSymbol() + " placed successfully!";
    }

    @GetMapping("/orders")
    public Iterable<MarketOrder> getAllOrders() {
        return marketOrderRepository.findAll();
    }
}
