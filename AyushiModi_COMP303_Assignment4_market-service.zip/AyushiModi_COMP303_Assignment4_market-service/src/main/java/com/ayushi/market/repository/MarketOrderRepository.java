package com.ayushi.market.repository;

import com.ayushi.market.model.MarketOrder;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MarketOrderRepository extends MongoRepository<MarketOrder, String> {
}
