package com.ayushi.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushiModiComp303Assignment4AccountServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
