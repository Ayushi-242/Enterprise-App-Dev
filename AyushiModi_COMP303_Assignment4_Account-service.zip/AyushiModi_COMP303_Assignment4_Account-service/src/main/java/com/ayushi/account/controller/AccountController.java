package com.ayushi.account.controller;

import com.ayushi.account.model.Account;
import com.ayushi.account.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    // Endpoint to create a new account
    @PostMapping("/create")
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        Account createdAccount = accountService.createAccount(account);
        return new ResponseEntity<>(createdAccount, HttpStatus.CREATED);
    }

    // Endpoint to get account by userId
    @GetMapping("/{userId}")
    public ResponseEntity<Account> getAccount(@PathVariable String userId) {
        Account account = accountService.getAccountByUserId(userId);
        if (account != null) {
            return new ResponseEntity<>(account, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to update account balance
    @PutMapping("/{userId}/update")
    public ResponseEntity<Account> updateAccount(@PathVariable String userId, @RequestParam double newBalance) {
        Account updatedAccount = accountService.updateAccountBalance(userId, newBalance);
        if (updatedAccount != null) {
            return new ResponseEntity<>(updatedAccount, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to delete account by userId
    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteAccount(@PathVariable String userId) {
        accountService.deleteAccount(userId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
