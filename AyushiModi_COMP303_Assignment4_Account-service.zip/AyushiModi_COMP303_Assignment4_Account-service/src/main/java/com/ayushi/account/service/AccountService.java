package com.ayushi.account.service;

import com.ayushi.account.model.Account;
import com.ayushi.account.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    // Create a new account
    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    // Get account by userId
    public Account getAccountByUserId(String userId) {
        return accountRepository.findByUserId(userId);
    }

    // Update account balance
    public Account updateAccountBalance(String userId, double newBalance) {
        Account account = accountRepository.findByUserId(userId);
        if (account != null) {
            account.setBalance(newBalance);
            return accountRepository.save(account);
        }
        return null; // or throw an exception if needed
    }

    // Delete account by userId
    public void deleteAccount(String userId) {
        Account account = accountRepository.findByUserId(userId);
        if (account != null) {
            accountRepository.delete(account);
        }
    }
}
