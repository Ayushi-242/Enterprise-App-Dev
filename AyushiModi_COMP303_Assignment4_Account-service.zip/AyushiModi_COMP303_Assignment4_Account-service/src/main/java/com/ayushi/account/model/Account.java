package com.ayushi.account.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "accounts")
public class Account {

    @Id
    private String id;
    private String userId;
    private double balance;
    private String accountType;

    // Default constructor
    public Account() {}

    // Constructor with fields
    public Account(String userId, double balance, String accountType) {
        this.userId = userId;
        this.balance = balance;
        this.accountType = accountType;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    // Override toString() if needed
    @Override
    public String toString() {
        return "Account [id=" + id + ", userId=" + userId + ", balance=" + balance + ", accountType=" + accountType + "]";
    }
}
