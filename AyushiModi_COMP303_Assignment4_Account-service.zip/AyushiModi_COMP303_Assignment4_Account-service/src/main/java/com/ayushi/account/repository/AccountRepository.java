package com.ayushi.account.repository;

import com.ayushi.account.model.Account;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends MongoRepository<Account, String> {

    // Custom query method to find Account by UserId
    Account findByUserId(String userId);
}
