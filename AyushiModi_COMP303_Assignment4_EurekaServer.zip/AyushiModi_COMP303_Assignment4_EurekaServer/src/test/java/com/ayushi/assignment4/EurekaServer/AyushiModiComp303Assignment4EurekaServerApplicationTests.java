package com.ayushi.assignment4.EurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushiModiComp303Assignment4EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
