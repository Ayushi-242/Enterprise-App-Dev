package com.ayushi.frontend.model;

//Ensure the MarketOrder class has the correct fields.
public class MarketOrder {
 private String stockName;
 private int quantity;
 private double price;

 // Getters and Setters
 public String getStockName() {
     return stockName;
 }

 public void setStockName(String stockName) {
     this.stockName = stockName;
 }

 public int getQuantity() {
     return quantity;
 }

 public void setQuantity(int quantity) {
     this.quantity = quantity;
 }

 public double getPrice() {
     return price;
 }

 public void setPrice(double price) {
     this.price = price;
 }
}
