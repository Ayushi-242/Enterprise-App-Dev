package com.ayushi.frontend.controller;

import com.ayushi.frontend.model.MarketOrder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
public class FrontendController {

    private final RestTemplate restTemplate;

    @Value("${market-service.url}")
    private String marketServiceUrl;

    // Constructor to initialize RestTemplate
    public FrontendController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Display the initial page
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("marketOrder", new MarketOrder());
        return "index"; // Return the view for the form to place stock orders
    }

    // Place Stock Order
    @PostMapping("/place-stock-order")
    public String placeStockOrder(@ModelAttribute MarketOrder marketOrder, Model model) {
        // URL for the market service where orders are placed
        String url = marketServiceUrl + "/market/place-order";

        try {
            // Make a POST request to the backend service with the market order
            restTemplate.postForObject(url, marketOrder, String.class);
            // If successful, add a success message to the model
            model.addAttribute("successMessage", "Stock order placed successfully!");
        } catch (Exception e) {
            // If there is an error, add an error message to the model
            model.addAttribute("errorMessage", "Error placing the stock order. Please try again.");
        }

        return "index"; // Return the same page to show the success or error message
    }
}
