package com.ayushi.frontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyushiModiComp303Assignment4FrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyushiModiComp303Assignment4FrontendApplication.class, args);
	}

}
