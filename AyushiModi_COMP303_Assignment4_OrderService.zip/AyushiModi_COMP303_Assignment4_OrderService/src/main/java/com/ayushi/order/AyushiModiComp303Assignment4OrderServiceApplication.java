package com.ayushi.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AyushiModiComp303Assignment4OrderServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(AyushiModiComp303Assignment4OrderServiceApplication.class, args);
    }
}
