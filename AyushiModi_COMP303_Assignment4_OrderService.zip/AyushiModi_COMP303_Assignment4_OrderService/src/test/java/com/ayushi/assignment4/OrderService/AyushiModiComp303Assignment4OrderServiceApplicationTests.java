package com.ayushi.assignment4.OrderService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushiModiComp303Assignment4OrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
